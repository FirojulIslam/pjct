<?php include "config/config.php"; ?>
<?php include "lib/Database.php"; ?>
<?php
$db = new Database();


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <title>Document</title>
</head>
<body>
  <div class="flex flex-row">
    <div class="bg-green-300">
      <ul>
        <?php
        $quarry="SELECT * FROM category";
        $show = $db->select($quarry);
        if ($show) {
          while ($result = $show->fetch_assoc()) {
        ?>
        <li><a href="categoryView.php?id=<?php echo $result['id']?>"><?php echo $result['category_name']?></a></li>
        <?php
            }
          }
        ?>
      </ul>
    </div>
  </div>
</body>
</html>